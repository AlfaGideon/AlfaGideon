import { 
  type User, 
  type InsertUser, 
  type Lesson,
  type InsertLesson,
  type Enrollment,
  type InsertEnrollment,
  type AdminSettings,
  type InsertAdminSettings
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByTelegramId(telegramId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;
  getUsersByRole(role: string): Promise<User[]>;

  // Lesson methods
  getLesson(id: string): Promise<Lesson | undefined>;
  getLessonsByTutor(tutorId: string): Promise<Lesson[]>;
  createLesson(lesson: InsertLesson): Promise<Lesson>;
  getAllLessons(): Promise<Lesson[]>;

  // Enrollment methods
  getEnrollment(id: string): Promise<Enrollment | undefined>;
  getEnrollmentsByStudent(studentId: string): Promise<Enrollment[]>;
  getEnrollmentsByLesson(lessonId: string): Promise<Enrollment[]>;
  createEnrollment(enrollment: InsertEnrollment): Promise<Enrollment>;
  updateEnrollment(id: string, updates: Partial<Enrollment>): Promise<Enrollment | undefined>;

  // Admin methods
  getAdminSettings(): Promise<AdminSettings | undefined>;
  createOrUpdateAdminSettings(settings: InsertAdminSettings): Promise<AdminSettings>;
  verifyAdminPassword(password: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private lessons: Map<string, Lesson>;
  private enrollments: Map<string, Enrollment>;
  private adminSettings: AdminSettings | undefined;

  constructor() {
    this.users = new Map();
    this.lessons = new Map();
    this.enrollments = new Map();
    
    // Initialize with default admin password
    this.adminSettings = {
      id: randomUUID(),
      adminPassword: "admin123",
      settings: {}
    };
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByTelegramId(telegramId: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.telegramId === telegramId,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getUsersByRole(role: string): Promise<User[]> {
    return Array.from(this.users.values()).filter(user => user.role === role);
  }

  async getLesson(id: string): Promise<Lesson | undefined> {
    return this.lessons.get(id);
  }

  async getLessonsByTutor(tutorId: string): Promise<Lesson[]> {
    return Array.from(this.lessons.values()).filter(lesson => lesson.tutorId === tutorId);
  }

  async createLesson(insertLesson: InsertLesson): Promise<Lesson> {
    const id = randomUUID();
    const lesson: Lesson = {
      ...insertLesson,
      id,
      createdAt: new Date()
    };
    this.lessons.set(id, lesson);
    return lesson;
  }

  async getAllLessons(): Promise<Lesson[]> {
    return Array.from(this.lessons.values());
  }

  async getEnrollment(id: string): Promise<Enrollment | undefined> {
    return this.enrollments.get(id);
  }

  async getEnrollmentsByStudent(studentId: string): Promise<Enrollment[]> {
    return Array.from(this.enrollments.values()).filter(enrollment => enrollment.studentId === studentId);
  }

  async getEnrollmentsByLesson(lessonId: string): Promise<Enrollment[]> {
    return Array.from(this.enrollments.values()).filter(enrollment => enrollment.lessonId === lessonId);
  }

  async createEnrollment(insertEnrollment: InsertEnrollment): Promise<Enrollment> {
    const id = randomUUID();
    const enrollment: Enrollment = {
      ...insertEnrollment,
      id,
      createdAt: new Date()
    };
    this.enrollments.set(id, enrollment);
    return enrollment;
  }

  async updateEnrollment(id: string, updates: Partial<Enrollment>): Promise<Enrollment | undefined> {
    const enrollment = this.enrollments.get(id);
    if (!enrollment) return undefined;
    
    const updatedEnrollment = { ...enrollment, ...updates };
    this.enrollments.set(id, updatedEnrollment);
    return updatedEnrollment;
  }

  async getAdminSettings(): Promise<AdminSettings | undefined> {
    return this.adminSettings;
  }

  async createOrUpdateAdminSettings(settings: InsertAdminSettings): Promise<AdminSettings> {
    if (this.adminSettings) {
      this.adminSettings = { ...this.adminSettings, ...settings };
    } else {
      this.adminSettings = {
        ...settings,
        id: randomUUID()
      };
    }
    return this.adminSettings;
  }

  async verifyAdminPassword(password: string): Promise<boolean> {
    return this.adminSettings?.adminPassword === password;
  }
}

export const storage = new MemStorage();
