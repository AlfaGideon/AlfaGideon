import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertLessonSchema, insertEnrollmentSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post("/api/auth/telegram", async (req, res) => {
    try {
      const { telegramId, username, firstName, lastName, role } = req.body;
      
      // Check if user already exists
      let user = await storage.getUserByTelegramId(telegramId);
      
      if (!user) {
        // Create new user
        const userData = insertUserSchema.parse({
          telegramId,
          username,
          firstName,
          lastName,
          role
        });
        user = await storage.createUser(userData);
      }
      
      res.json(user);
    } catch (error) {
      res.status(400).json({ message: "Invalid user data" });
    }
  });

  app.post("/api/auth/admin", async (req, res) => {
    try {
      const { password } = req.body;
      const isValid = await storage.verifyAdminPassword(password);
      
      if (!isValid) {
        return res.status(401).json({ message: "Неверный пароль администратора" });
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // User routes
  app.get("/api/users", async (req, res) => {
    try {
      const { role } = req.query;
      let users;
      
      if (role) {
        users = await storage.getUsersByRole(role as string);
      } else {
        // Return all users (admin only functionality)
        users = await storage.getUsersByRole("student");
        const tutors = await storage.getUsersByRole("tutor");
        const admins = await storage.getUsersByRole("administrator");
        users = [...users, ...tutors, ...admins];
      }
      
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Ошибка получения пользователей" });
    }
  });

  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ message: "Пользователь не найден" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Lesson routes
  app.get("/api/lessons", async (req, res) => {
    try {
      const { tutorId } = req.query;
      let lessons;
      
      if (tutorId) {
        lessons = await storage.getLessonsByTutor(tutorId as string);
      } else {
        lessons = await storage.getAllLessons();
      }
      
      res.json(lessons);
    } catch (error) {
      res.status(500).json({ message: "Ошибка получения уроков" });
    }
  });

  app.post("/api/lessons", async (req, res) => {
    try {
      const lessonData = insertLessonSchema.parse(req.body);
      const lesson = await storage.createLesson(lessonData);
      res.json(lesson);
    } catch (error) {
      res.status(400).json({ message: "Неверные данные урока" });
    }
  });

  // Enrollment routes
  app.get("/api/enrollments", async (req, res) => {
    try {
      const { studentId, lessonId } = req.query;
      let enrollments;
      
      if (studentId) {
        enrollments = await storage.getEnrollmentsByStudent(studentId as string);
      } else if (lessonId) {
        enrollments = await storage.getEnrollmentsByLesson(lessonId as string);
      } else {
        enrollments = [];
      }
      
      res.json(enrollments);
    } catch (error) {
      res.status(500).json({ message: "Ошибка получения записей" });
    }
  });

  app.post("/api/enrollments", async (req, res) => {
    try {
      const enrollmentData = insertEnrollmentSchema.parse(req.body);
      const enrollment = await storage.createEnrollment(enrollmentData);
      res.json(enrollment);
    } catch (error) {
      res.status(400).json({ message: "Неверные данные записи" });
    }
  });

  app.patch("/api/enrollments/:id", async (req, res) => {
    try {
      const { progress, completedAt } = req.body;
      const enrollment = await storage.updateEnrollment(req.params.id, {
        progress,
        completedAt: completedAt ? new Date(completedAt) : undefined
      });
      
      if (!enrollment) {
        return res.status(404).json({ message: "Запись не найдена" });
      }
      
      res.json(enrollment);
    } catch (error) {
      res.status(500).json({ message: "Ошибка обновления записи" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
