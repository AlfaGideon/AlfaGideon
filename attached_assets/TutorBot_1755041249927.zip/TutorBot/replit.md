# RussianMentor - Telegram Mini App

## Overview

RussianMentor is a Telegram Mini App designed for Russian language learning, featuring role-based access for students, tutors, and administrators. The application provides interactive lessons, progress tracking, user management, and administrative controls, all optimized for the Telegram Web App platform with native haptic feedback and UI integration.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite for build tooling and development server
- **UI Components**: Shadcn/ui component library with Radix UI primitives for accessibility
- **Styling**: Tailwind CSS with custom Telegram-themed color palette and design system
- **State Management**: TanStack Query for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Mobile-First Design**: Optimized for Telegram's mobile interface with responsive breakpoints

### Backend Architecture
- **Runtime**: Node.js with Express.js web framework
- **Language**: TypeScript with ES modules for modern JavaScript features
- **API Design**: RESTful API with JSON responses and error handling middleware
- **Data Layer**: In-memory storage implementation with interface for future database integration
- **Authentication**: Telegram-based authentication using Web App user data

### Role-Based Access Control
- **Student Role**: Access to lessons, progress tracking, and learning materials
- **Tutor Role**: Lesson management, student oversight, and content creation capabilities
- **Administrator Role**: User management, system settings, and password-protected access

### Telegram Integration
- **Web App SDK**: Native Telegram Web App JavaScript SDK integration
- **Haptic Feedback**: Platform-specific tactile feedback for user interactions
- **Theme Integration**: Automatic adaptation to Telegram's light/dark theme preferences
- **Native UI Elements**: MainButton and BackButton integration for seamless UX

### Data Storage Strategy
- **Current Implementation**: In-memory storage with full CRUD operations
- **Database Schema**: PostgreSQL-ready schema using Drizzle ORM with type-safe queries
- **Schema Design**: Users, lessons, enrollments, and admin settings with proper relationships
- **Migration Support**: Drizzle Kit for database schema management and version control

### Development Architecture
- **Monorepo Structure**: Shared schema and types between client and server
- **Hot Reload**: Vite HMR for rapid development with Express middleware integration
- **Type Safety**: End-to-end TypeScript with shared interfaces and validation schemas
- **Build Process**: Separate client (Vite) and server (esbuild) build pipelines

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React 18+ with TypeScript support and modern hooks
- **Express.js**: Web application framework with middleware support
- **Vite**: Build tool and development server with plugin ecosystem

### UI and Styling
- **Tailwind CSS**: Utility-first CSS framework with custom configuration
- **Radix UI**: Headless component library for accessible UI primitives
- **Shadcn/ui**: Pre-built component system with consistent design patterns
- **Lucide React**: Icon library for consistent iconography

### Database and ORM
- **Drizzle ORM**: Type-safe PostgreSQL ORM with schema validation
- **Neon Database**: Serverless PostgreSQL database service (@neondatabase/serverless)
- **Drizzle Kit**: Database toolkit for migrations and schema management

### State Management
- **TanStack Query**: Server state management with caching and synchronization
- **React Hook Form**: Form state management with validation support
- **Zod**: Runtime type validation and schema parsing

### Telegram Platform
- **Telegram Web Apps**: Official Telegram SDK for mini app development
- **Platform APIs**: Haptic feedback, theme detection, and native UI controls

### Development Tools
- **TypeScript**: Static type checking and enhanced developer experience
- **ESBuild**: Fast JavaScript bundler for server-side code
- **PostCSS**: CSS processing with Tailwind and Autoprefixer plugins