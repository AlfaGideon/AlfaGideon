import { hapticFeedback } from '@/lib/telegram';

interface RoleCardProps {
  role: 'student' | 'tutor' | 'administrator';
  title: string;
  description: string;
  features: string[];
  color: string;
  icon: React.ReactNode;
  onClick: () => void;
}

export function RoleCard({ role, title, description, features, color, icon, onClick }: RoleCardProps) {
  const handleClick = () => {
    hapticFeedback('medium');
    onClick();
  };

  return (
    <div 
      className="role-card telegram-haptic bg-telegram-card rounded-2xl p-6 shadow-lg cursor-pointer"
      onClick={handleClick}
      data-testid={`role-card-${role}`}
    >
      <div className="flex items-start space-x-4">
        <div 
          className={`w-16 h-16 rounded-2xl flex items-center justify-center flex-shrink-0`}
          style={{ backgroundColor: color }}
        >
          <div className="w-8 h-8 text-white">
            {icon}
          </div>
        </div>
        <div className="flex-1">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xl font-bold text-telegram-text">{title}</h3>
            <svg className="w-5 h-5 text-telegram-secondary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path>
            </svg>
          </div>
          <p className="text-telegram-secondary text-sm mb-4">{description}</p>
          <ul className="space-y-2 text-sm text-telegram-secondary">
            {features.map((feature, index) => (
              <li key={index} className="flex items-center">
                <span 
                  className="w-1.5 h-1.5 rounded-full mr-3"
                  style={{ backgroundColor: color }}
                ></span>
                {feature}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
