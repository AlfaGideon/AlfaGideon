import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { initTelegramWebApp, getTelegramWebApp } from '@/lib/telegram';

interface TelegramUser {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
}

interface TelegramContextType {
  user: TelegramUser | null;
  isReady: boolean;
  webApp: any;
}

const TelegramContext = createContext<TelegramContextType>({
  user: null,
  isReady: false,
  webApp: null,
});

export function TelegramProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<TelegramUser | null>(null);
  const [isReady, setIsReady] = useState(false);
  const [webApp, setWebApp] = useState<any>(null);

  useEffect(() => {
    const tg = initTelegramWebApp();
    setWebApp(tg);

    if (tg) {
      // Get user data from Telegram
      const telegramUser = tg.initDataUnsafe?.user;
      if (telegramUser) {
        setUser(telegramUser);
      } else {
        // Fallback for development
        setUser({
          id: 123456789,
          first_name: 'Тестовый',
          last_name: 'Пользователь',
          username: 'testuser',
          language_code: 'ru'
        });
      }
      setIsReady(true);
    } else {
      // Development mode without Telegram
      setUser({
        id: 123456789,
        first_name: 'Тестовый',
        last_name: 'Пользователь',
        username: 'testuser',
        language_code: 'ru'
      });
      setIsReady(true);
    }
  }, []);

  return (
    <TelegramContext.Provider value={{ user, isReady, webApp }}>
      {children}
    </TelegramContext.Provider>
  );
}

export function useTelegram() {
  const context = useContext(TelegramContext);
  if (!context) {
    throw new Error('useTelegram must be used within a TelegramProvider');
  }
  return context;
}
