import { motion } from 'framer-motion';
import { hapticFeedback } from '@/lib/telegram';

interface AnimatedCardProps {
  children: React.ReactNode;
  className?: string;
  delay?: number;
  onClick?: () => void;
  testId?: string;
  hoverScale?: number;
  tapScale?: number;
}

export function AnimatedCard({ 
  children, 
  className = '', 
  delay = 0, 
  onClick,
  testId,
  hoverScale = 1.02,
  tapScale = 0.98
}: AnimatedCardProps) {
  const handleClick = () => {
    if (onClick) {
      hapticFeedback('light');
      onClick();
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay }}
      whileHover={{ scale: hoverScale }}
      whileTap={{ scale: tapScale }}
      onClick={handleClick}
      className={`cursor-pointer ${className}`}
      data-testid={testId}
    >
      {children}
    </motion.div>
  );
}